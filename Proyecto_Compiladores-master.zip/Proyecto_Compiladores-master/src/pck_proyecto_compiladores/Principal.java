package pck_proyecto_compiladores;

import java.io.File;

//Creación de nuestro Lexer.java
public class Principal {
    public static void main(String[] args) {
        String ruta = "C:/Users/Usuario/Documents/UMG/7mo. Semestre/Compiladores/ProyectoFinal/Proyecto_CompiladoresV1.3/Proyecto_CompiladoresV1.2/src/pck_proyecto_compiladores/Lexer.flex";
        generarLexer(ruta);
    }
    
   public static void generarLexer(String ruta){
       File archivo = new File(ruta);
       JFlex.Main.generate(archivo);
   }
}
