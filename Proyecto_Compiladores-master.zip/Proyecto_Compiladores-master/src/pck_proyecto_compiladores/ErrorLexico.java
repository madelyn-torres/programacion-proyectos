package pck_proyecto_compiladores;

public class ErrorLexico {
    private String tipo;
    private String mensaje;
    private int linea;
    private int columna;

    public ErrorLexico(String tipo, String mensaje, int linea, int columna) {
        this.tipo = tipo;
        this.mensaje = mensaje;
        this.linea = linea;
        this.columna = columna;
    }
    
    // Getters
    public String getTipo() { return tipo; }
    public String getMensaje() { return mensaje; }
    public int getLinea() { return linea; }
    public int getColumna() { return columna; }
}
