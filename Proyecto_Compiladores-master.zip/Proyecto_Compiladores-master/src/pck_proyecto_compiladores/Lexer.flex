package pck_proyecto_compiladores;

import static pck_proyecto_compiladores.Tokens.*;
import pck_proyecto_compiladores.Token;
import pck_proyecto_compiladores.ManejadorErrores;

%%
%class Lexer
%type Token // Cambiado de Tokens a Token
%state PROGRAMA
%unicode
%line
%column
%{
    private Token crearToken(Tokens tipo, String valor) {
        return new Token(tipo, valor, yyline + 1, yycolumn + 1);
    }
%}

// Macros (Expresiones Reutilizables)
LetraMin       = [a-z]
LetraMay       = [A-Z]
Digito         = [0-9]
Espacio        = [ \t\r\n]
Identificador  = {LetraMin}({LetraMin}|{LetraMay}|{Digito}|"_")*
NombrePrograma = [A-Za-z_][A-Za-z0-9_]*
Cadena         = '([^'\\]|\\.)*'
Decimal        = {Digito}+"."{Digito}+
Entero         = {Digito}+
Booleano       = "Vrd"|"Fls"
CadenaDoble = \"([^\"\\]|\\.)*\"
ComentarioLinea = "#/".*
ComentarioBloque = "#/" ~"/#"

%%

/* Reglas Léxicas */
// Palabras Reservadas (Case-Sensitive)
"EMPEZAR PROGRAMA"     { yybegin(PROGRAMA); return crearToken(EMPEZAR_PROGRAMA, yytext()); }
"TERMINAR PROGRAMA"    { return crearToken(TERMINAR_PROGRAMA, yytext()); }
"EMPEZAR METODO"       { return crearToken(EMPEZAR_METODO, yytext()); }
"TERMINAR METODO"      { return crearToken(TERMINAR_METODO, yytext()); }
"SI"                   { return crearToken(SI, yytext()); }
"CONTRARIO"            { return crearToken(CONTRARIO, yytext()); }
"SINO"                 { return crearToken(SINO, yytext()); }
"INICIO"               { return crearToken(INICIO, yytext()); }     //Cambio por EMPEZAR
"FIN"                  { return crearToken(FIN, yytext()); }        //Cambio por TERMINAR
"SEGUN"                { return crearToken(SEGUN, yytext()); }
"CASO"                 { return crearToken(CASO, yytext()); }
"ROMPE"                { return crearToken(ROMPE, yytext()); }
"PARA"                 { return crearToken(PARA, yytext()); }
"MIENTRAS"             { return crearToken(MIENTRAS, yytext()); }
"HAZ"                  { return crearToken(HAZ, yytext()); }
"LEER"                 { return crearToken(LEER, yytext()); }
"IMPRIMIR"             { return crearToken(IMPRIMIR, yytext()); }
"Y"|"O"|"NO"           { return crearToken(OPERADOR_LOGICO, yytext()); }


// SÍMBOLOS Y OPERADORES
"->"                   { return crearToken(DECLARACION, yytext()); }
"="                    { return crearToken(ASIGNACION, yytext()); }
"+"|"-"|"*"|"/"|"%"    { return crearToken(OPERADOR_ARITMETICO, yytext()); }
"<"|">"|"=>"|"<="|"=="|"!=" { return crearToken(OPERADOR_RELACIONAL, yytext()); }
"["|"]"|"("|")"|","    { return crearToken(SIMBOLO, yytext()); }
":"                    { return crearToken(DOS_PUNTOS, yytext()); }


// Paréntesis y comas
"(" { return crearToken(PARENTESIS_ABRE, yytext()); }
")" { return crearToken(PARENTESIS_CIERRA, yytext()); }
"," { return crearToken(COMA, yytext()); }

// Tipos de Datos y Valores
{Cadena}               { return crearToken(CADENA, yytext()); }
{Decimal}              { return crearToken(DECIMAL, yytext()); }
{Entero}               { return crearToken(ENTERO, yytext()); }
{Booleano}             { return crearToken(BOOLEANO, yytext()); }
{CadenaDoble}          { return crearToken(CADENA_DOBLE, yytext()); }


<PROGRAMA> {
    {Espacio}+    { /* Ignorar espacios */ } // <- Nuevo: ignorar espacios
    {NombrePrograma} { 
        yybegin(YYINITIAL); 
        return crearToken(NOMBRE_PROGRAMA, yytext()); 
    }
    [^] { 
        ManejadorErrores.agregarError("LÉXICO", "Nombre de programa inválido", yyline + 1, yycolumn + 1);
        yybegin(YYINITIAL); 
        return crearToken(ERROR, yytext());
    }
}


// Identificadores (Case-Sensitive, minúscula inicial)
{Identificador}        { 
    if (yytext().length() > 25) {
        ManejadorErrores.agregarError("LÉXICO", "Identificador muy largo", yyline + 1, yycolumn + 1);
    }
    return crearToken(IDENTIFICADOR, yytext()); 
}


// ERRORES LÉXICOS
[0-9]+{Identificador}  { 
    ManejadorErrores.agregarError("LÉXICO", "Identificador inválido (no puede empezar con número)", yyline + 1, yycolumn + 1);
    return crearToken(ERROR, yytext());
}

{LetraMay}{Identificador} { 
    ManejadorErrores.agregarError("LÉXICO", "Identificador inválido (debe comenzar con minúscula)", yyline + 1, yycolumn + 1);
    return crearToken(ERROR, yytext());
}


// Cadenas dobles (para LEER/IMPRIMIR)
{CadenaDoble} { 
    return crearToken(CADENA_DOBLE, yytext()); 
}


// Comentarios
{ComentarioLinea}      { /* Ignorar */ }
{ComentarioBloque}     { /* Ignorar */ }

// Espacios
{Espacio}+             { /* Ignorar espacios */ }

// Errores

\"[^\"]*              { 
    ManejadorErrores.agregarError("LÉXICO", "Cadena doble no cerrada", yyline + 1, yycolumn + 1);
    return crearToken(ERROR, yytext());
}

'[^']*                 { 
    ManejadorErrores.agregarError("LÉXICO", "Cadena no cerrada", yyline + 1, yycolumn + 1);
    return crearToken(ERROR, yytext());
}
.                      { 
    ManejadorErrores.agregarError("LÉXICO", "Carácter no válido: '" + yytext() + "'", yyline + 1, yycolumn + 1);
    return crearToken(ERROR, yytext());
}