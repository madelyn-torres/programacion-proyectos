package pck_proyecto_compiladores;

import java.util.List;
import java.util.ArrayList;

public class ManejadorErrores {
     private static List<ErrorLexico> errores = new ArrayList<>();
    
    public static void agregarError(String tipo, String mensaje, int linea, int columna) {
        errores.add(new ErrorLexico(tipo, mensaje, linea, columna));
    }
    
    public static List<ErrorLexico> getErrores() {
        return new ArrayList<>(errores);
    }
    
    public static void limpiarErrores() {
        errores.clear();
    } 
}
