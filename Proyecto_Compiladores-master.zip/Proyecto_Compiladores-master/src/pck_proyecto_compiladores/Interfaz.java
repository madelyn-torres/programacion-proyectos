
package pck_proyecto_compiladores;
//Diseño realizado por Madelyn
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.StringReader;
import pck_proyecto_compiladores.Lexer;


public class Interfaz extends javax.swing.JFrame {

    
   private DefaultTableModel modeloTokens;
   private DefaultTableModel modeloErrores;
   
    public Interfaz() {
        initComponents();
        configurarModelos();
    }

    private void configurarModelos() {
        // Modelo para tokens
        modeloTokens = new DefaultTableModel(
            new Object[]{"#", "Lexema", "Tipo", "Línea", "Columna"}, 0
        );
        tblToken.setModel(modeloTokens);
        
        // Modelo para errores
        modeloErrores = new DefaultTableModel(
            new Object[]{"Tipo", "Descripción", "Línea", "Columna"}, 0
        );
        tblErrores.setModel(modeloErrores);
        
        // Configurar anchos de columnas
        tblToken.getColumnModel().getColumn(0).setPreferredWidth(40);
        tblToken.getColumnModel().getColumn(3).setPreferredWidth(60);
        tblToken.getColumnModel().getColumn(4).setPreferredWidth(60);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblToken = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblErrores = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btnAnalizar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel1.setText("ERRORES:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 460, 100, -1));

        tblToken.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tblToken);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 610, 250));

        tblErrores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblErrores);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 490, 610, 250));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane4.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 410, 460));

        btnAnalizar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAnalizar.setText("Analizar");
        btnAnalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalizarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAnalizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 680, 140, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel2.setText("ANALIZADOR LÉXICO");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 60, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel4.setText("Ingrese el texto:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 140, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel5.setText("TOKENS:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 170, 100, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/logo.png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 170, 80));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ANALIZADOR LEXICO.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 830));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAnalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalizarActionPerformed
        modeloTokens.setRowCount(0);
        modeloErrores.setRowCount(0);
        ManejadorErrores.limpiarErrores();

        String codigo = jTextArea1.getText();
        Lexer lexer = new Lexer(new StringReader(codigo));

        try {
            Token token;
            int contador = 1;
            while ((token = lexer.yylex()) != null) {
                if (token.getTipo() != Tokens.ERROR) {
                    modeloTokens.addRow(new Object[]{
                        contador++,
                        token.getValor(),
                        token.getTipo().name(),
                        token.getLinea(),
                        token.getColumna()
                    });
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al analizar: " + e.getMessage());
        }

        // Mostrar errores
        for (ErrorLexico error : ManejadorErrores.getErrores()) {
            modeloErrores.addRow(new Object[]{
                error.getTipo(),
                error.getMensaje(),
                error.getLinea(),
                error.getColumna()
            });
        }
    }//GEN-LAST:event_btnAnalizarActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnalizar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTable tblErrores;
    private javax.swing.JTable tblToken;
    // End of variables declaration//GEN-END:variables
}

