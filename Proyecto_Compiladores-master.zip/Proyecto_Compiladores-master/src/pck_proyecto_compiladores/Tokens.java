package pck_proyecto_compiladores;


public enum Tokens {
    // Palabras Reservadas
    EMPEZAR_PROGRAMA,
    NOMBRE_PROGRAMA,
    TERMINAR_PROGRAMA,
    EMPEZAR_METODO,
    TERMINAR_METODO,
    SI,
    CONTRARIO,
    SINO,
    SEGUN,
    CASO,
    ROMPE,
    PARA,
    MIENTRAS,
    HAZ,
    LEER,
    IMPRIMIR,
    INICIO,       // Añadido para bloques
    FIN,      // Añadido para bloques
    OPERADOR_LOGICO,
    
    // Simbolos y Operadores
     DECLARACION,    // ->
    ASIGNACION,     // =
    OPERADOR_ARITMETICO,  // + - * / %
    OPERADOR_RELACIONAL,  // < > == != <= =>
    DOS_PUNTOS,     // :
    SIMBOLO,
    COMA,
    
    // Tipos de Datos
    CADENA,         // 'texto'
    CADENA_DOBLE,   // "texto"
    DECIMAL,        // 3.14
    ENTERO,         // 42
    BOOLEANO,       // Vrd o Fls
    IDENTIFICADOR,  // nombre_variable
 
    // Errores
    ERROR
}
