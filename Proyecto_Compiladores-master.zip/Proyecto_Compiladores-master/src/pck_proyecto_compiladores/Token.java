package pck_proyecto_compiladores;


public class Token {
    private Tokens tipo;
    private String valor;
    private int linea;
    private int columna;
    
     public Token(Tokens tipo, String valor, int linea, int columna) {
        this.tipo = tipo;
        this.valor = valor;
        this.linea = linea;
        this.columna = columna;
    }
    
    public Tokens getTipo() { return tipo; }
    public String getValor() { return valor; }
    public int getLinea() { return linea; }
    public int getColumna() { return columna; }
    
}
